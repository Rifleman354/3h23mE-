nut.lang.Add("note_created", "You've created note.")
nut.lang.Add("note_submit", "You've refreshed note.")
nut.lang.Add("note_name", "A Note.")
nut.lang.Add("note_desc", "Something is written on it.")