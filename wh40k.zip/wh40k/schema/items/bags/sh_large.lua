ITEM.name = "Large Bag"
ITEM.desc = "A big bag capable of holding a lot of items."
ITEM.invWidth = 4
ITEM.invHeight = 3
ITEM.permit = "misc"