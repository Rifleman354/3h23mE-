ITEM.name = "Shotgun Ammo"
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "tfa_ammo_buckshot" // type of the ammo
ITEM.ammoAmount = 50 // amount of the ammo
ITEM.ammoDesc = "Shotgun Ammo"
ITEM.category = "Ammunition"
ITEM.flag = "y"