ITEM.name = "Lasgun Battery"
ITEM.model = "models/bloocobalt/dow/weapons/laspistol_powercell.mdl"
ITEM.ammo = "tfa_ammo_ar2" // type of the ammo
ITEM.ammoAmount = 1000 // amount of the ammo
ITEM.ammoDesc = ""
ITEM.category = "Ammunition"
ITEM.flag = "y"