ITEM.name = "Chaos Power Axe"
ITEM.desc = ""
ITEM.model = "models/rocks/weapons/poweraxe.mdl"
ITEM.class = "tfa_poweraxe_chaos"
ITEM.weaponCategory = "Melee"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 3