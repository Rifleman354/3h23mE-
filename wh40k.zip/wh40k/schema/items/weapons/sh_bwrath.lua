ITEM.name = "Bloody Wrath"
ITEM.desc = "The Blade of a Khorne, if you lsien closely you hear demonic whisper's of Death"
ITEM.model = "models/rocks/weapons/bloody_wreath.mdl"
ITEM.class = "tfa_bloodywreath"
ITEM.weaponCategory = "Melee"
ITEM.price = 999999
ITEM.width = 2
ITEM.height = 5