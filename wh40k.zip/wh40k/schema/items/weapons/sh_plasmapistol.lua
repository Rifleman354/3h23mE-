ITEM.name = "Plasma Pistol"
ITEM.desc = ""
ITEM.model = "models/weapons/weapons/plasmapistol.mdl"
ITEM.class = "tfa_zad_plasmapistol"
ITEM.weaponCategory = "sidearm"
ITEM.width = 2
ITEM.price = 10000000
ITEM.height = 1
ITEM.flag = "IG"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}