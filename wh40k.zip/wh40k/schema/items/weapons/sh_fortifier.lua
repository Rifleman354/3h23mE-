ITEM.name = "Fortifier"
ITEM.desc = ""
ITEM.model = "models/kobilica/wiremonitorrt.mdl"
ITEM.class = "alydus_fortificationbuildertablet"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 99999999999
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}