ITEM.name = "Chaos Plasma Pistol"
ITEM.desc = "Get's hot!"
ITEM.model = "models/weapons/plasmapistol_chaos.mdl"
ITEM.class = "tfa_plasmapistol_chaos"
ITEM.weaponCategory = "Sidearm"
ITEM.price = 999999
ITEM.width = 2
ITEM.height = 2