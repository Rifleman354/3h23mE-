ITEM.name = "Shoota"
ITEM.desc = ""
ITEM.model = "models/dow2/ork_weapons/goff/shoota.mdl"
ITEM.class = "tfa_shoota"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 10000000
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}