ITEM.name = "Chaos Boltgun"
ITEM.desc = "A weapon wielded by the chosen of the gods. It would surely break the arms of most mortal men."
ITEM.model = "models/rocks/weapons/bolter_chaos.mdl"
ITEM.class = "tfa_bolter_chaos"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 3
ITEM.height = 2