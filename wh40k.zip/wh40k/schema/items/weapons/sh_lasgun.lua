ITEM.name = "Lasgun"
ITEM.desc = "A Lasgun"
ITEM.model = "models/weapons/ig_lasgun.mdl"
ITEM.class = "weapon_lasguncadia"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 4