ITEM.name = "Chaos Bolt Pistol"
ITEM.desc = "A weapon wielded by the chosen of the gods. It would surely break the arms of most mortal men."
ITEM.model = "models/rocks/weapons/boltpistol.mdl"
ITEM.class = "tfa_chaos_boltpistol"
ITEM.weaponCategory = "Sidearm"
ITEM.price = 999999
ITEM.width = 2
ITEM.height = 2