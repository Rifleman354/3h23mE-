ITEM.name = "Deamon Blade"
ITEM.desc = "The Blade of a Deamon, if you lsien closely you hear demonic whisper's"
ITEM.model = "models/rocks/weapons/sword_daemonblade.mdl"
ITEM.class = "tfa_deamonsword"
ITEM.weaponCategory = "Melee"
ITEM.price = 999999
ITEM.width = 2
ITEM.height = 3