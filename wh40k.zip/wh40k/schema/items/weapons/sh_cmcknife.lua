ITEM.name = "Chaos Marine Combat Knife"
ITEM.desc = "An Astartes knife. It's a sword in the hands of a mortal."
ITEM.model = "models/rocks/weapons/combatknife.mdl"
ITEM.class = "tfa_combatknife_chaos"
ITEM.weaponCategory = "Melee"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 2