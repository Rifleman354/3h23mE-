ITEM.name = "Chaos Chainaxe"
ITEM.desc = "An iconic Khornate weapon."
ITEM.model = "models/rocks/weapons/chainaxe_curved.mdl"
ITEM.class = "tfa_chainaxe_chaos"
ITEM.weaponCategory = "Melee"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 3