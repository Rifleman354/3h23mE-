ITEM.name = "Chaos Combi-Boltgun"
ITEM.desc = "Combining the unbridled fury of a Plasmagun with the raw power of the Boltgun. This weapon is a rare treasure."
ITEM.model = "models/rocks/weapons/bolter_combi.mdl"
ITEM.class = "tfa_combi_plasma_chaos"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 3
ITEM.height = 2