ITEM.name = "Sabre"
ITEM.desc = ""
ITEM.model = "models/weapons/w_cutlass2/w_cutlass2.mdl"
ITEM.class = "weapon_psw_sabre"
ITEM.weaponCategory = "melee"
ITEM.width = 2
ITEM.height = 1
ITEM.price = 10000000
ITEM.iconCam = {
	ang	= Angle(-0.23955784738064, 270.44906616211, 0),
	fov	= 10.780103254469,
	pos	= Vector(0, 200, 0)
}