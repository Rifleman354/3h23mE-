ITEM.name = "Chaos Heavy Bolter"
ITEM.desc = ""
ITEM.model = "models/rocks/weapons/bolter_twinlinked.mdl"
ITEM.class = "tfa_heavybolter_chaos"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 5
ITEM.height = 3