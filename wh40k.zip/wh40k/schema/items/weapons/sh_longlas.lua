ITEM.name = "Longlas"
ITEM.desc = "A Longlas"
ITEM.model = "models/weapons/longlas.mdl"
ITEM.class = "weapon_longlascadia"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 4