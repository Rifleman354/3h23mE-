ITEM.name = "Stalker Bolter"
ITEM.desc = ""
ITEM.model = "models/zadkiel/weapons/bolter_stalkerbolter.mdl"
ITEM.class = "tfa_zad_stalkerbolter"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 3
ITEM.height = 2