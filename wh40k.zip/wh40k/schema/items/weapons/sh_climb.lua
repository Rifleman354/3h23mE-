ITEM.name = "Climb"
ITEM.desc = ""
ITEM.model = "models/props_lab/jar01a.mdl"
ITEM.class = "climb_swep2"
ITEM.weaponCategory = "primary"
ITEM.width = 1
ITEM.price = 0
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}