ITEM.name = "Boltpistol"
ITEM.desc = "A semi-automatic handgun"
ITEM.model = "models/weapons/weapons/boltpistol.mdl"
ITEM.class = "tfa_zad_boltpistol"
ITEM.weaponCategory = "sidearm"
ITEM.width = 2
ITEM.height = 1
ITEM.price = 10000000
ITEM.flag = "y"
ITEM.iconCam = {
	ang	= Angle(0.33879372477531, 270.15808105469, 0),
	fov	= 5.0470897275697,
	pos	= Vector(0, 200, -1)
}