ITEM.name = "Chaos Storm Bolter"
ITEM.desc = "A Laspistol"
ITEM.model = "models/weapons/laspistol.mdl"
ITEM.class = "weapon_laspistolcadia"
ITEM.weaponCategory = "Sidearm"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 2