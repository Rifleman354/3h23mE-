ITEM.name = "Meltagun"
ITEM.desc = "A powerful energy-based CQC weapon"
ITEM.class = "tfa_zad_meltacadia"
ITEM.weaponCategory = "primary"
ITEM.model = "models/weapons/w_meltagun.mdl"
ITEM.width = 4
ITEM.height = 2
ITEM.price = 10000000
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}
ITEM.flag = "y"