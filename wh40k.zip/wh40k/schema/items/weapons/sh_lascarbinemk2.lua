ITEM.name = "LasCarbineM2"
ITEM.desc = "Pair this up with a heavy weapon, and it becomes your best friend"
ITEM.model = "models/weapons/w_laspistol_gun.mdl"
ITEM.class = "weapon_imp_lascarb_ig_mk2"
ITEM.weaponCategory = "primary"
ITEM.width = 2
ITEM.price = 10000000
ITEM.height = 1
ITEM.flag = "IG"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}