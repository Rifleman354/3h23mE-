ITEM.name = "Assassin Bolt Pistol"
ITEM.desc = "A weapon wielded by the Assassin's of Chaos. It would surely incenarate the arms of most mortal men."
ITEM.model = "models/weapons/w_laspistol.mdl"
ITEM.class = "weapon_laspistolassassin"
ITEM.weaponCategory = "Sidearm"
ITEM.price = 999999
ITEM.width = 2
ITEM.height = 2