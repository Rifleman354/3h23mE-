ITEM.name = "Auto Shotgun"
ITEM.desc = "A Automatic Shotgun now for the worshipers of Choas."
ITEM.model = "models/weapons/w_ig_shotgun.mdl"
ITEM.class = "weapon_shotgun60_nope"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 3
ITEM.height = 2