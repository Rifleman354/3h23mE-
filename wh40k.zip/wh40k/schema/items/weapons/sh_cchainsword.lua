ITEM.name = "Chaos Chainsword"
ITEM.desc = ""
ITEM.model = "models/rocks/weapons/chainsword.mdl"
ITEM.class = "tfa_chainsword_chaos"
ITEM.weaponCategory = "Melee"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 3