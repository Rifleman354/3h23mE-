ITEM.name = "Poweraxe"
ITEM.desc = "An augmented melee weapon"
ITEM.model = "models/weapons/weapons/poweraxe_basic.mdl"
ITEM.class = "tfa_zad_poweraxe"
ITEM.weaponCategory = "melee"
ITEM.width = 2
ITEM.height = 1
ITEM.price = 10000000
ITEM.flag = "y"
ITEM.iconCam = {
	ang	= Angle(-0.23955784738064, 270.44906616211, 0),
	fov	= 10.780103254469,
	pos	= Vector(0, 200, 0)
}