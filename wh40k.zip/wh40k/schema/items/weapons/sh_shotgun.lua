ITEM.name = "Shotgun"
ITEM.desc = "A powerful pump-action shotgun."
ITEM.class = "weapon_40k_shotgun"
ITEM.weaponCategory = "primary"
ITEM.model = "models/weapons/w_shot_warham.mdl"
ITEM.width = 4
ITEM.height = 2
ITEM.price = 10000000
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}
