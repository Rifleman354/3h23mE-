ITEM.name = "Psychic Powers"
ITEM.desc = "Possession of this item makes you a Psyker. Do not drop or trade this item. Your gifts are powerful but wrathful. Use them sparingly."
ITEM.model = "models/Gibs/HGIBS.mdl"
ITEM.class = "weapon_hpwr_stick"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 2
ITEM.height = 2