ITEM.name = "Lascarbine"
ITEM.desc = "A Lascarbine"
ITEM.model = "models/weapons/lascarabin.mdl"
ITEM.class = "weapon_lascarabine"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 4