ITEM.name = "Accursed Crozius"
ITEM.desc = ""
ITEM.model = "models/rocks/weapons/powermace_accursedcrozius.mdl"
ITEM.class = "tfa_accurced_crozius"
ITEM.weaponCategory = "Melee"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 3