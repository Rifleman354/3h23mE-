ITEM.name = "Portable Heavy Stubber"
ITEM.desc = "A heavy Stubber"
ITEM.model = "models/weapons/sk_heavyst.mdl"
ITEM.class = "tfa_heavy_stabber"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 10000000
ITEM.height = 2
ITEM.flag = "IG"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}