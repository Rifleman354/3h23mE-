ITEM.name = "Chaos Plasma Gun"
ITEM.desc = "Gets hot!"
ITEM.model = "models/weapons/plasmagun_chaos.mdl"
ITEM.class = "tfa_plasmagun_chaos"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 3
ITEM.height = 2