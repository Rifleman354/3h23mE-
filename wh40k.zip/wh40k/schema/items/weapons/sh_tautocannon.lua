ITEM.name = "Terminator Autocannon"
ITEM.desc = "Far too heavy for mortal man, it packs quite the punch."
ITEM.model = "models/rocks/weapons/w_terminator_autocannon_reg_autocannon_chaos.mdl"
ITEM.class = "tfa_terminator_chaos_autocannon"
ITEM.weaponCategory = "Primary"
ITEM.price = 999999
ITEM.width = 5
ITEM.height = 3