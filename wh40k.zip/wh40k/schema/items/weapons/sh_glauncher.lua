ITEM.name = "RPG"
ITEM.desc = ""
ITEM.model = "models/weapons/weapons/missilelauncher.mdl"
ITEM.class = "tfa_zad_fraglaunchers"
ITEM.weaponCategory = "primary"
ITEM.price = 10000000
ITEM.width = 4
ITEM.height = 2
ITEM.iconCam = {
	pos = Vector(-19.607843399048, 200, 2),
	ang = Angle(0, 270, 0),
	fov = 16
}
ITEM.flag = "Y"