ITEM.name = "Chaos Power Sword"
ITEM.desc = ""
ITEM.model = "models/rocks/weapons/sword_powersword.mdl"
ITEM.class = "tfa_powersword_chaos"
ITEM.weaponCategory = "Melee"
ITEM.price = 999999
ITEM.width = 1
ITEM.height = 3