FACTION.name = "Tzeentch"
FACTION.desc = ""
FACTION.color = Color(0, 0, 255)
FACTION.isDefault = false
FACTION.models = {
	"models/player/impy/guardsman.mdl"
}
FACTION.isGloballyRecognized = true

FACTION_TZEENTCH = FACTION.index