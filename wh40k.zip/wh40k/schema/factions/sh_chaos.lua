FACTION.name = "Chaos Undivided"
FACTION.desc = ""
FACTION.color = Color(0, 0, 0)
FACTION.isDefault = false
FACTION.models = {
	"models/player/impy/guardsman.mdl"
}
FACTION.isGloballyRecognized = true

FACTION_CHAOS = FACTION.index