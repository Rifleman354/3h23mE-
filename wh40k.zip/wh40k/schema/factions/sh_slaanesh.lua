FACTION.name = "Slaanesh"
FACTION.desc = ""
FACTION.color = Color(255, 0, 255)
FACTION.isDefault = false
FACTION.models = {
	"models/player/impy/guardsman.mdl"
}
FACTION.isGloballyRecognized = true

FACTION_SLAANESH = FACTION.index