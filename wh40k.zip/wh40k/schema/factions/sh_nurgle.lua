FACTION.name = "Nurgle"
FACTION.desc = ""
FACTION.color = Color(0, 255, 0)
FACTION.isDefault = false
FACTION.models = {
	"models/player/impy/guardsman.mdl"
}
FACTION.isGloballyRecognized = true

FACTION_NURGLE = FACTION.index