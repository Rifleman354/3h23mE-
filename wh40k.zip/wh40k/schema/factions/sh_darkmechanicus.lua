FACTION.name = "Dark Mechanicus"
FACTION.desc = ""
FACTION.color = Color(145, 0, 0)
FACTION.isDefault = false
FACTION.models = {
	"models/player/impy/guardsman.mdl"
}
FACTION.isGloballyRecognized = true

FACTION_DARKMECH = FACTION.index