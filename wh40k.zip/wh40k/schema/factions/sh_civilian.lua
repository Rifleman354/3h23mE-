FACTION.name = "Unemployed"
FACTION.desc = "Get yourself a job, bum!"
FACTION.color = Color(0,255,0)
FACTION.isDefault = true
FACTION.models = {"models/player/Barney.mdl"}

FACTION_UNEMPLOYED = FACTION.index