FACTION.name = "47th Red Rock Corporation"
FACTION.desc = ""
FACTION.color = Color(255, 0, 0)
FACTION.isDefault = false
FACTION.models = {
	"models/player/impy/guardsman.mdl"
}

FACTION.isGloballyRecognized = true

FACTION_RRC = FACTION.index