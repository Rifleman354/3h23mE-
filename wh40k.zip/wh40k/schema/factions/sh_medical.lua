FACTION.name = "Medical"
FACTION.desc = ""
FACTION.color = Color(241, 244, 66)
FACTION.isDefault = false
FACTION.models = {
	"models/player/impy/guardsman.mdl",
}

FACTION.isGloballyRecognized = true
function FACTION:onSpawn(client)
    client:SetHealth(100) 
    client:SetMaxHealth(100) 
    client:SetArmor(150)
end

FACTION_MED = FACTION.index