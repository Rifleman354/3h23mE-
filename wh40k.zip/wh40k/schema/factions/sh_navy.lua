FACTION.name = "Navy"
FACTION.desc = ""
FACTION.color = Color(51, 51, 255)
FACTION.isDefault = false
FACTION.models = {
	"models/player/impy/guardsman.mdl"
}

FACTION.isGloballyRecognized = true

function FACTION:onSpawn(client)
    client:SetHealth(100) 
    client:SetMaxHealth(100) 
end

FACTION_NAVY = FACTION.index